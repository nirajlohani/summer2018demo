# summer2018demo

This is a SFDX project to demo inline edit in lightning:datatable, lightning:recordForm and custom lightning flexipage:layouts.

You'll need a Summer'18 scratch org with sample Contact data.

> This is a "down and dirty demo", so if you find errors, please feel free to create a PR.

